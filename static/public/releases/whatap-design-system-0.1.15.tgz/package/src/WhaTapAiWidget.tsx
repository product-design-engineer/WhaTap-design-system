/**
 * WhaTapAiWidget — AI surface. 480px 우측 슬라이드 패널형 WhaTap AI 위젯.
 *
 * ## Purpose
 * 대시보드 우측에 폭 480px(닫히면 0)로 펼쳐지는 AI 어시스턴트 패널. 그라데이션
 * 40px 헤더(새 세션/전체화면/닫기) + 본문(랜딩 인사말 + 액션 칩, 또는 시나리오
 * 메시지 스택) + 하단 입력 영역(첨부 칩 행 · multi-line textarea · 첨부 버튼 ·
 * 토큰 사용량 pill · 전송 버튼)으로 구성. 마크업은 /application/slider 라이브
 * 위젯과 동일하게 재현(side-effect-free)하고 데이터는 모두 prop 으로 외부화.
 *
 * ## When to use
 * - [[DashboardLayout]] 의 `children` 슬롯에 들어가는 위젯 본체 — 세로 전체 높이를 쓰는 대화 패널.
 * - 랜딩 인사말 + 빠른 액션 칩 + 토큰 사용량 + 첨부까지 풀 chrome 이 필요한 자리.
 *
 * ## When NOT to use
 * - 세로 공간이 한정된 헤더/카드/모달의 한 줄 입력 → [[InlinePrompt]] (single-row).
 * - 헤더 안 AI 토글 버튼만 필요 → [[AssistantButton]].
 * - 라이브 vercel 위젯의 440px 변형(Beta 배지 · 모델 선택기) 재현 → [[AiWidget]].
 *
 * ## Composition rules
 * - 폭은 `open` 이 결정(480px ↔ 0), `transition: width 0.4s` 로 애니메이션. [[DashboardLayout]]
 *   에서 Sidebar collapse 와 동기화(feedback-widget-sidebar-collapse).
 * - editable mode: `inputValue` 미지정이면 내부 state 로 사용자가 직접 입력, `onSubmit`
 *   은 입력값이 있을 때만 Enter(shift 제외)/전송 버튼으로 호출. `inputValue` 지정 시 readOnly 데모.
 * - `scrollSignal` 이 바뀔 때마다 본문을 부드럽게 최하단으로 자동 스크롤(메시지 추가 후 반영).
 * - 색·경계는 토큰 binding (`--color-brand-blue` / `--color-brand-blue-bg-2` 등).
 * - `showLanding=true` 일 때만 인사말+칩 렌더, `messages` 는 그 아래 시나리오 스택으로 누적.
 *
 * @example
 * ```tsx
 * <WhaTapAiWidget
 *   open={aiActive}
 *   onClose={() => setAiActive(false)}
 *   onNewSession={resetSession}
 *   onFullscreen={goFullscreen}
 *   user="Wha-tap Kim"
 *   pageHighlight="GPU 트렌드"
 *   actions={["현재 상태 요약", "이상 징후 진단"]}
 *   onSubmit={(v) => askAi(v)}
 * />
 * ```
 */
import { useEffect, useRef, useState } from "react";
import AiClickCursor from "./widget/ClickCursor";
import SendButton from "./widget/SendButton";
import AiActionChip from "./widget/ActionChip";
import AiAttachmentChip from "./widget/AttachmentChip";
import AiUnavailableNotice, {
  type AiUnavailableNoticeProps,
} from "./widget/UnavailableNotice";

const WIDGET_WIDTH = 480;

export type WidgetAction = string;

/** 쓸 수 없는 입력창에서 입력칸 · 첨부 · 전송만 흐리고 막는다. 재원 알약은 빼고(위 설명). */
const UNAVAILABLE_DIM = { opacity: 0.5, pointerEvents: "none" } as const;

export default function WhaTapAiWidget({
  open,
  onClose,
  onNewSession,
  onFullscreen,
  user = "Wha-tap Kim",
  pageHighlight = "애플리케이션 대시보드",
  intro,
  actions = ["현재 상태 요약", "이상 징후 진단", "슬로우 트랜잭션 분석"],
  messages,
  inputValue,
  showLanding = true,
  attachments,
  scrollSignal,
  showSendCursor = false,
  onSubmit,
  inputPlaceholder = "어떤 작업을 함께 할까요?",
  unavailable,
  inputCaption,
  usagePill,
  titleBadge,
  onStop,
}: {
  open: boolean;
  onClose?: () => void;
  onNewSession?: () => void;
  onFullscreen?: () => void;
  user?: string;
  /**
   * 헤더 제목 「WhaTap AI」 옆에 서는 뱃지. 이 대화가 «무엇으로 나가는가» 를 상시로 말한다
   * (재원 이름 — 무료 · plan 이름).
   *
   * 잔량은 여기 적지 않는다. 종류와 잔량은 다른 기준이고, 잔량은 «보내는 자리»(입력창 pill)에
   * 붙어야 뜻이 선다. 헤더에 숫자까지 넣으면 위젯 꼭대기가 과금 계기판이 된다.
   */
  titleBadge?: import("react").ReactNode;
  pageHighlight?: string;
  /**
   * 환영 문단 전체를 갈아끼운다. 주면 `user`·`pageHighlight` 로 조립하는 기본 문장을 쓰지 않는다.
   *
   * 기본 문장은 한국어로 고정돼 있어, 영문 화면이나 «분석» 이라는 말이 맞지 않는 제품에서는
   * `pageHighlight` 만 바꿔서는 해결되지 않는다. 그럴 때 문단을 통째로 받는다.
   */
  intro?: import("react").ReactNode;
  actions?: WidgetAction[];
  messages?: import("react").ReactNode;
  inputValue?: string;
  showLanding?: boolean;
  /** 입력 영역 위에 노출할 첨부 파일 칩들 (Figma 27087:3416). */
  attachments?: { name: string; mime?: string }[];
  /**
   * 값이 변할 때마다 콘텐츠 영역을 부드럽게 최하단으로 자동 스크롤.
   * 시나리오 stage 같은 progress signal을 그대로 전달하면 됨.
   */
  scrollSignal?: unknown;
  /** true면 송신 버튼 위에 자동 클릭 손 커서 표시(데모용). */
  showSendCursor?: boolean;
  /**
   * 사용자가 input 에 입력 후 Enter 또는 send 버튼 클릭 시 호출.
   * inputValue 가 undefined 일 때만 활성 (editable mode).
   */
  onSubmit?: (value: string) => void;
  /** 입력창 placeholder 문구. 시나리오별 시작 prompt 안내에 사용. */
  inputPlaceholder?: string;
  /**
   * 입력창 아래 caption. 기본은 정확성 고지 한 줄이고, 그 줄에 «이 질문이 어떻게 나가는가» 에
   * 해당하는 사실(범위 · 재원 따위)을 덧붙일 때만 넘긴다.
   *
   * 자리를 새로 만들지 않고 이 줄을 여는 이유는, 그런 사실이 붙어야 하는 곳이 «보내는 자리» 이기
   * 때문이다. 대화 위쪽에 두면 대화가 길어질 때 위로 사라지고, 액션 칩 줄에 두면 «누르면 질문이
   * 나간다» 는 뜻과 섞인다. 기본 고지는 지우지 말 것 — 늘 붙어 있어야 한다.
   */
  inputCaption?: import("react").ReactNode;
  /**
   * 입력창 pill 내용 교체. 주면 토큰 수 대신 이 내용이 그 자리에 선다(껍데기는 그대로).
   * 토큰 수는 개발이 보는 값이라, 과금 단위가 토큰이 아닌 제품에서는 사용자가 그 숫자로 할 수
   * 있는 판단이 없다. 둘을 나란히 두지 말 것 — 단위가 둘이 되면 사람이 환산을 계산한다.
   */
  usagePill?: import("react").ReactNode;
  /**
   * 값이 있으면 특정 사유로 AI 사용이 불가한 상태 — 랜딩/시나리오 대신
   * [[UnavailableNotice]] 안내를 본문에 노출하고 입력창을 비활성화합니다.
   * preset 사유만 쓰려면 `{ reason: "quota" }` 처럼 전달.
   */
  unavailable?: AiUnavailableNoticeProps;
  /**
   * AI 가 답을 만드는 중이면 넘긴다. 송신 버튼 자리가 중단 버튼(■)이 되고, 누르면 이 함수가 불린다.
   * 입력창은 막지 않는다 — 작업 중에도 다음 질문을 미리 쓸 수 있다. 대신 Enter 로 보내지는 않는다
   * (끝나고 보낸다). 진행 표시는 [[AiProgress]] 가 본문에서 맡는다. 끝나면 `undefined` 로 되돌린다.
   */
  onStop?: () => void;
}) {
  const isUnavailable = unavailable != null;
  // editable mode: parent 가 inputValue 를 지정하지 않으면 사용자가 직접 입력.
  const editable = inputValue === undefined && !isUnavailable;
  const [typed, setTyped] = useState("");
  const effectiveValue = editable ? typed : inputValue ?? "";
  const hasInput = effectiveValue.trim().length > 0;

  const handleSubmit = () => {
    if (onStop || !hasInput || !onSubmit) return;
    onSubmit(effectiveValue);
    setTyped("");
  };
  const handleKey = (e: import("react").KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };
  const scrollRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!scrollRef.current) return;
    // 다음 paint 시점에 스크롤(새로 추가된 콘텐츠 높이 반영 후).
    const id = requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (!el) return;
      el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    });
    return () => cancelAnimationFrame(id);
  }, [scrollSignal]);
  return (
    <div
      className="shrink-0 overflow-hidden relative"
      style={{
        width: open ? WIDGET_WIDTH : 0,
        transition: "width 0.4s ease-in-out",
      }}
    >
      {/* 좌측 리사이즈 핸들 */}
      <div
        className="absolute left-0 top-0 bottom-0 z-10 flex items-center justify-center"
        style={{ width: 6, cursor: "col-resize" }}
      >
        <div
          className="rounded-full transition-colors duration-150"
          style={{ width: 3, height: 32, backgroundColor: "var(--color-border-divider)" }}
        />
      </div>

      <div
        className="flex flex-col h-full bg-card border-l border-color-var-color-border-default"
        style={{ width: WIDGET_WIDTH }}
      >
        {/* 헤더 (40px, 그라데이션) */}
        <div
          className="flex h-40px items-center px-16px py-8px shrink-0 w-full relative overflow-visible z-10"
          style={{
            background:
              "linear-gradient(138.94deg, var(--color-whatap-blue) 2.33%, var(--color-whatap-purple) 107.07%)",
          }}
        >
          <div className="flex flex-1 items-center justify-between min-w-0">
            <div className="flex gap-4px items-center shrink-0">
              <img alt="" className="size-16px" src="/icons/ai-header-symbol.svg" />
              <span
                data-ds-policy-ok="AI 그라데이션 헤더 위 전경 — 컬러 배경 위 고정 흰색"
                // raw-color-ok: AI 그라데이션 헤더 위 전경 — 컬러 배경 위 고정 흰색.
                className="text-lg font-bold text-white tracking-default whitespace-nowrap"
                style={{ fontFamily: "var(--font-family-korean)" }}
              >
                WhaTap AI
              </span>
              {/* 재원 뱃지 — 제목 바로 옆. 그라데이션 위라 색은 흰색 계열로 고정한다.
                  반투명 흰 배경 위 흰 글자여서 배경색을 갈아 끼우지 않아도 두 상태가 구분된다. */}
              {titleBadge && (
                <span
                  data-ds-policy-ok="AI 그라데이션 헤더 위 전경 — 컬러 배경 위 고정 흰색"
                  // raw-color-ok: AI 그라데이션 헤더 위 전경 — 컬러 배경 위 고정 흰색.
                  className="inline-flex items-center h-18px rounded-24px text-xs text-white whitespace-nowrap shrink-0"
                  style={{
                    fontFamily: "var(--font-family-korean)",
                    fontWeight: "var(--font-weight-medium)",
                    // raw-color-ok: AI 그라데이션 헤더 위 반투명 흰 알약 — 컬러 배경 위 고정 흰색.
                    background: "rgba(255,255,255,0.22)",
                    /* 좌우 여백은 토큰으로 — 6px 은 4px 스케일 위에 없던 값이었다. 알약 안에
                       글자만 있던 때는 좁아도 됐지만, 지금은 꺾쇠가 같이 들어간다. */
                    paddingInline: "var(--space-2)",
                    /* 제목과의 사이 — 종전 `ml-2px` 는 토큰이 아니었다. 컨테이너 `gap-4px` 에
                       이 값이 더해져 제목 ↔ 칩 사이가 8px 이 된다. */
                    marginLeft: "var(--space-1)",
                  }}
                >
                  {titleBadge}
                </span>
              )}
            </div>
            <div className="flex gap-8px items-center shrink-0">
              <button
                type="button"
                onClick={onNewSession}
                aria-label="새로운 세션 추가"
                className="shrink-0 size-20px cursor-pointer hover-opacity-80 transition-opacity flex items-center justify-center relative"
              >
                <img alt="새로운 세션추가" src="/icons/ai-header-plus.svg" style={{ height: 14 }} />
              </button>
              <button
                type="button"
                onClick={onFullscreen}
                aria-label="전체 크기"
                className="shrink-0 size-20px cursor-pointer hover-opacity-80 transition-opacity flex items-center justify-center relative"
              >
                <img
                  alt="전체 크기"
                  src="/icons/ai-header-fullscreen.svg"
                  style={{ width: 16, height: 16 }}
                />
              </button>
              <button
                type="button"
                onClick={onClose}
                aria-label="닫기"
                className="shrink-0 size-20px cursor-pointer hover-opacity-80 transition-opacity flex items-center justify-center relative"
              >
                <img alt="닫기" src="/icons/ai-header-close.svg" style={{ height: 14 }} />
              </button>
            </div>
          </div>
        </div>

        {/* 본문 — 인사말 + 액션 칩 (showLanding=true일 때만). ref → scrollSignal 변경 시 자동 스크롤 */}
        <div
          ref={scrollRef}
          className="flex-1 min-h-0 flex flex-col items-center gap-16px overflow-y-auto overflow-x-hidden w-full pt-16px pb-8px px-16px"
        >
          {isUnavailable && <AiUnavailableNotice {...unavailable} />}

          {!isUnavailable && showLanding && (
          // key={open}로 위젯을 열 때마다 인사말 영역이 remount되어 entrance animation 재생
          <div key={open ? "open" : "closed"} className="bg-card flex flex-col items-start justify-center relative w-full">
            {/* AI 심볼 (호흡 + 회전) — 진입 시 fade-in이 한 번 추가로 재생 */}
            <div className="ai-anim-in mb-12px" style={{ animationDelay: "0ms" }}>
              <div
                className="relative shrink-0"
                style={{
                  width: 24,
                  height: 24,
                  animation:
                    "aiSymbolBreathing 3s ease-in-out infinite, aiSymbolRotateSlow 25s linear infinite",
                }}
              >
                <img alt="" className="w-full h-full" src="/icons/ai-symbol-gradient.svg" />
              </div>
            </div>

            <div className="flex flex-col gap-16px items-start w-full">
              <div className="flex flex-1 flex-col gap-16px items-start justify-center min-w-0">
                <p
                  className="ai-anim-in text-md text-primary tracking-default w-full whitespace-pre-wrap leading-normal"
                  style={{
                    fontFamily: "var(--font-family-korean)",
                    fontWeight: "var(--font-weight-regular)",
                    animationDelay: "150ms",
                  }}
                >
                  {intro ?? (
                    <>
                      <span
                        className="font-bold text-lg tracking-default"
                        style={{ fontFamily: "var(--font-family-korean)" }}
                      >
                        {user}
                      </span>
                      <span className="text-md leading-normal whitespace-pre-wrap">
                        님, 안녕하세요. WhaTap AI입니다.{"\n"}
                      </span>
                      <span
                        className="font-bold text-lg tracking-default"
                        style={{ fontFamily: "var(--font-family-korean)" }}
                      >
                        {pageHighlight}
                      </span>
                      <span className="text-md leading-normal whitespace-pre-wrap">
                        {" "}분석을 함께 하겠습니다. 무엇부터 살펴볼까요?
                      </span>
                    </>
                  )}
                </p>

                {/* 액션 칩 */}
                <div className="flex flex-wrap gap-6px items-start w-full">
                  {actions.map((label, i) => (
                    <AiActionChip key={label} label={label} index={i} />
                  ))}
                </div>
              </div>
            </div>
          </div>
          )}

          {/* 시나리오 메시지 스택 */}
          {!isUnavailable && messages && (
            <div className="flex flex-col gap-16px w-full">{messages}</div>
          )}
        </div>

        {/* Input 영역 */}
        <div className="flex flex-col items-center justify-center px-16px shrink-0 w-full">
          <div
            className="ai-input-wrapper relative bg-card flex flex-col gap-4px items-center justify-center p-12px shrink-0 rounded-8px transition-all duration-200 w-full"
            style={{
              border: hasInput ? "2px solid var(--color-brand-blue)" : "2px solid var(--color-brand-blue-bg-2)",
            }}
            aria-disabled={isUnavailable || undefined}
          >
            {/* 쓸 수 없을 때 흐리고 막는 것은 입력칸 · 첨부 · 전송뿐이다. 재원 알약(usagePill)은 그 상태에서
                빠져나가는 길(「범위에 추가」 · 「결제권한자에게 요청」 · 「납부하기」)이라 또렷하게 두고 누를 수 있게 한다.
                전에는 감싸는 상자 전체에 opacity · pointer-events 를 걸어 알약까지 마우스로 누를 수 없었다. */}
            {/* 첨부 파일 칩 행 (Figma 27087:3416) */}
            {attachments && attachments.length > 0 && (
              <div className="flex gap-6px items-center w-full overflow-x-auto pb-4px">
                {attachments.map((a, i) => (
                  <AiAttachmentChip key={i} name={a.name} mime={a.mime} />
                ))}
              </div>
            )}
            <div className="flex gap-0 items-center p-2px w-full" style={isUnavailable ? UNAVAILABLE_DIM : undefined}>
              <textarea
                placeholder={isUnavailable ? "지금은 WhaTap AI 를 사용할 수 없습니다" : inputPlaceholder}
                rows={1}
                value={effectiveValue}
                readOnly={!editable}
                disabled={isUnavailable}
                onChange={editable ? (e) => setTyped(e.target.value) : undefined}
                onKeyDown={editable ? handleKey : undefined}
                className="ai-input-textarea w-full text-lg text-primary tracking-default resize-none outline-none border-0 bg-transparent placeholder-text-disabled"
                style={{
                  fontFamily: "var(--font-family-korean)",
                  fontWeight: "var(--font-weight-regular)",
                  minHeight: 20,
                  maxHeight: 120,
                }}
              />
            </div>
            <div className="flex items-center justify-between p-0 w-full">
              <div className="flex gap-8px items-center shrink-0">
                <input
                  multiple
                  accept=".csv,.pdf,.txt,.json,.log,image/*"
                  type="file"
                  style={{ display: "none" }}
                />
                <button
                  type="button"
                  aria-label="파일 또는 이미지 추가"
                  style={isUnavailable ? UNAVAILABLE_DIM : undefined}
                  className="group-plus flex items-center justify-center p-2px rounded-4px shrink-0 size-20px cursor-pointer border-0 bg-card hover-bg-invert transition-colors"
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="transition-colors">
                    <line x1="8" y1="3.33" x2="8" y2="12.67" className="stroke-color-var-color-text-secondary group-hover-plus-stroke-invert" strokeWidth="1.5" strokeLinecap="round" />
                    <line x1="3.33" y1="8" x2="12.67" y2="8" className="stroke-color-var-color-text-secondary group-hover-plus-stroke-invert" strokeWidth="1.5" strokeLinecap="round" />
                  </svg>
                </button>
                {/* 토큰 입출력 정보 (Figma 29424:19317) — plus 버튼 옆 pill */}
                {/* 재원 pill — 줄 것이 없으면 아무것도 그리지 않는다(빈 알약을 두지 않는다). */}
                {usagePill !== undefined && usagePill !== null && <UsagePill>{usagePill}</UsagePill>}
              </div>
              <div className="flex gap-8px items-center shrink-0">
                {/* 전송 버튼 — input에 텍스트가 있으면 활성(blue). 작업 중(onStop)이면 같은 자리가 중단 버튼 */}
                <div className="relative shrink-0" style={isUnavailable ? UNAVAILABLE_DIM : undefined}>
                {onStop ? (
                  <SendButton mode="stop" onClick={onStop} />
                ) : (
                <button
                  type="button"
                  disabled={!hasInput}
                  onClick={handleSubmit}
                  className="ai-send-btn flex items-center justify-center rounded-4px shrink-0 size-24px cursor-pointer transition-colors disabled-cursor-not-allowed"
                  style={{
                    backgroundColor: hasInput ? "var(--color-brand-blue)" : "var(--color-surface-50)",
                    border: hasInput
                      ? "1px solid var(--color-brand-blue)"
                      : "1px solid var(--color-border-strong)",
                  }}
                  aria-label="전송"
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path
                      d="M8 12V4M8 4L4 8M8 4L12 8"
                      data-ds-policy-ok="활성 시 brand-blue 배경 위 전경 — 컬러 위 고정 흰색"
                      // raw-color-ok: 활성 시 brand-blue 배경 위 전경 — 컬러 위 고정 흰색.
                      stroke={hasInput ? "#fff" : "var(--color-border-divider)"}
                      strokeWidth="1.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
                )}
                {showSendCursor && (
                  <AiClickCursor style={{ right: -18, top: 6 }} />
                )}
                </div>
              </div>
            </div>
          </div>
          <div className="flex gap-0 items-center justify-end px-0 py-4px shrink-0 w-full">
            <p
              className={`text-base text-disabled tracking-normal ${inputCaption ? "leading-normal text-right" : "leading-none whitespace-nowrap"}`}
              style={{ fontFamily: "var(--font-family-korean)", fontWeight: "var(--font-weight-regular)" }}
            >
              {inputCaption ?? "AI 응답은 정확하지 않을 수 있습니다. 중요한 결정은 반드시 확인해 주세요."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * UsagePill — 입력창 옆 알약 한 칸. 「이 질문이 어떻게 나가는가」 를 말한다.
 *
 * 2026-08-26 에 토큰 카운트(「토큰 입력 3,395 · 출력 181」)를 지웠다. 그 숫자는 개발이 보는
 * 값이라 사용자가 그것으로 할 수 있는 판단이 없었고, 과금 단위가 토큰이 아닌 제품에서는 화면이
 * 쓰지 않는 단위를 상시로 띄우고 있는 셈이었다. 알약 껍데기만 남기고 내용은 호출측이 정한다
 * (`usagePill`) — 재원 이름 · 남은 질문 횟수처럼 그 화면의 단위로 적는 자리다.
 *
 * 줄 것이 없으면 이 알약 자체를 그리지 않는다. 빈 알약은 「무언가 있어야 하는데 비었다」 로 읽힌다.
 */
function UsagePill({ children }: { children: import("react").ReactNode }) {
  return (
    <div
      className="inline-flex items-center px-8px py-4px rounded-24px shrink-0"
      style={{ backgroundColor: "var(--color-surface-50)" }}
      data-node-id="29424:19317"
    >
      <span
        className="text-xs text-primary whitespace-nowrap"
        style={{ fontFamily: "var(--font-family-korean-inter)", fontWeight: "var(--font-weight-regular)" }}
      >
        {children}
      </span>
    </div>
  );
}
